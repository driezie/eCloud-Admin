<?php

// Name: index.php
// Author: Jelte Cost
// Path: projects\simple-portfolio\index.php

require_once 'functions/dbh.php';
$dbh = dbConnection();

// adds visit counter to database by one 
function clientIpAddress(){
    if(!empty($_SERVER['HTTP_CLIENT_IP'])){
      $address = $_SERVER['HTTP_CLIENT_IP'];
    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
      $address = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }else{
      $address = $_SERVER['REMOTE_ADDR'];
    }
    return $address;
  }

function addVisitCounter() {
    global $dbh;
    $sql = "UPDATE config SET page_visits_index = page_visits_index + 1";
    $stmt = $dbh->prepare($sql);
    $stmt->execute();

    $sql = "INSERT INTO visits_log (id, ip, location, date, path) VALUES (NULL, :ip, :location, :date , :path)";
    $stmt = $dbh->prepare($sql);
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt->bindParam(':ip', $ip);
    $adress = clientIpAddress();
    $stmt->bindParam(':location', $adress);
    // set date to current date with seconds and minutes
    $date = date("Y-m-d H:i:s");
    $stmt->bindParam(':date', $date);

    // get path of the page from projects
    $path = $_SERVER['REQUEST_URI'];
    
    $stmt->bindParam(':path', $path);
    $stmt->execute();
} 
addVisitCounter();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driezie's Portfolio</title>
    <!-- Scroll Reveal Libary -->
    <script src="https://unpkg.com/scrollreveal"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    
    <link rel="stylesheet" href="./css/style.css">

    <link rel="stylesheet" href="./css/chart.css">
</head>
<body class="">
    <header>
        <nav class="container">
            <a href="index.html" class="logo"> <b>Port<span>folio</span></b></a>
            <div class="links">
                <ul>
                    <li style="display: none;">
                        <span class="nav-link-menu" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
                    </li>
                    <li>
                        <a class="nav-link" href="#1">Home</a>
                    </li>
                    <li>
                        <a class="nav-link" href="#2">About me</a>
                    </li>
                    <li>
                        <a class='nav-link' href='./customer/login.php'>Customer Login</a>
                    </li>
                </ul>
                <i class="uil uil-moon toggle-btn"></i>
            </div>
        </nav>
    </header>
    <main>
        <alert>
        <div id="myModal" class="modal" style="display: none">

        <!-- Modal content -->
        <div class="modal-content">
            <h3 class="alert-header">Nieuw Project 'Upgrading de eCloud met de back kant'</h3>
            <p class="alert-text">Voor school zijn we weet met een nieuw project bezig. Dit project is te volgen op: <a class="alert-link-text" href="https://github.com/driezie/eCloud">driezie/eCloud</a> op Github</p><br><br><p class="alert-close-text">Klik buiten dit venster op dit veld te sluiten</p>
        </div>

        </div>
                        
        </alert>
        <section class="showcase-area" id="1">
            <div class="container">
                <div class="showcase-info">

                    <h3 class="sub-heading">Web Developer / UI Designer</h3>
                    <h1 class="heading">Driezie</h1>
                    <p class="text">Web Developer at University of Utrecht. UI Designer for Roblox</p>
                    <div class="cta">
                        <a href="./customer/" class="btn">Order from me</a>
                        <a href="./customer/" class="btn secondary-btn">Customer Login</a>
                    </div>
                </div>
                <div class="showcase-image">
                    <img src="./assets/Avatar-4.png" class="person" alt="Jelte Cost">
                </div>
            </div>
        </section>

        <section class="about-area" id="2">
            <div class="container">
                <div class="about-info">
                    <h1 class="heading">About me</h1>
                    <p class="text">Hi! Thank you for visiting my portfolio! I've been in the Roblox Community for a few years already.</p>
                    <p class="text">In the beginning I started building but I fast realised that I am way better in designing UI's. Since 2018 I've been designing UI designs for a lot of groups.</p>
                    <div class="cta">
                        <a href="./customer/" class="btn">Order from me</a>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Javascript scripts -->

    <script src="./js/app2.js"></script>

</body>
</html>
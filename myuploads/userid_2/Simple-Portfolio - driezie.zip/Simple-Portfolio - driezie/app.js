const express = require('express')
const session = require('express-session')
const passport = require('passport')
const Strategy = require('passport-discord').Strategy

var phpExpress = require('php-express')({

    // assumes php is in your PATH
    binPath: './customer/index.php',
});

const app = express()
const port = 3000

passport.serializeUser(function(user, done) {
    done(null, user);
});
passport.deserializeUser(function(obj, done) {
    done(null, obj);
});

var scopes = ['identify','guilds'];

passport.use(new Strategy({
    clientID: "970436786968993852",
    clientSecret: "jnL5aC7Gb8W3KHi1ZT7nscpc5RUfFrzi",
    callbackURL: "http://127.0.0.1:3000/callback",
    scope: scopes
}, function(accessToken, refreshToken, profile, done) {
    process.nextTick(function() {
        return done(null, profile);
    });
}));


app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
app.get('/', passport.authenticate('discord', { scope: scopes }), function(req, res) {});

app.get('/callback',
    passport.authenticate('discord', { failureRedirect: '/' }), function(req, res) { res.redirect('/info') } // auth success
);

app.get('/info', checkAuth, function(req, res) {
    console.log("User logged in:")
    console.log("---------------")
    console.log("Username:" + req.user.username + "#" + req.user.discriminator)
    console.log("---------------")
    console.log("Id:" + req.user.id)
    console.log("---------------")
    res.redirect('/projects/Simple-Portfolio%20-%20driezie/customer/index.php');
});

app.get('/getuserdata', function(req, res) {
    res.json(req.user);
});

app.get('/logout', function(req, res) {
    req.logout();
    res.redirect('/');
});

function checkAuth(req, res, next) {
    if (req.isAuthenticated()) return next();
    res.sendfile('/projects/Simple-Portfolio%20-%20driezie/customer/index.php');
}


app.get('/test', checkAuth,(req, res) => {
    res.sendfile('./views/test.html');
})

app.get('/amogos', (req,res) => {
    res.sendfile("./views/error.html");
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
<?php

// Name: index.php
// Author: Jelte Cost
// Path: projects\simple-portfolio\index.php

require_once '../functions/dbh.php';
$dbh = dbConnection();

session_start();

if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
    // print_r($_SESSION);

} else {
    header("Location: ./login.php");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driezie's Portfolio</title>
    <!-- Scroll Reveal Libary -->
    <script src="https://unpkg.com/scrollreveal"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    
    <link rel="stylesheet" href="../css/style.css">
    
    

</head>
<body class="">
    <header>
        <nav class="container">
            <a href="./" class="logo"> <b>Dash<span>board</span></b></a>
            <div class="links">
                <ul>
                    <li style="display: none;">
                        <span class="nav-link-menu" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
                    </li>
                    <li>
                        <a class="nav-link" href="./">Home</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./orders.php">My orders</a>
                    </li>
                    <li>
                        <a class="nav-link" href="#">Chat with me</a>
                    </li>
                    <!-- <li>
                        <a class="nav-link" href="./data.php">Mijn Profiel</a>
                    </li> -->
                    <li>
                        <a class="nav-link" href="../functions/actions.php?value=logout"><b>Logout</b> (<?= $_SESSION[ 'username'] ?>)</a>
                    </li>
                    <li>
                    </li>
                </ul>
                <i class="uil uil-moon toggle-btn"></i>
            </div>
        </nav>
    </header>
    
    <main>
        <section class="chatting-area" id="1">
            <div class="container" >
                
                <div class="chatting-info" style="min-height: 1000px;">
                <div class="welcome-top-buttons">
                    <a href="./orders.php" class="btn btn-primary">My orders</a>
                    <a href="#" class="btn btn-primary">Chat with me</a>
                    <a href="../functions/actions.php?value=logout" class="btn btn-primary">Logout</a>
                </div>

                    <h3 class="sub-heading">Welcome, <?= $_SESSION[ 'username'] ?>! </h3>
                    <h1 class="heading">Chat with me</h1>
                    <p class="text">Chatting is currently not possible. driezie#9385</p>
                    <div class="chattingbox" scrolling="yes">
                        
                    <div class="chat-inputs">
                            <form action="../functions/actions.php"></form>
                                <div class="chat-input">
                                    <input type="text" placeholder="Type your message here...">
                                </div>
                                <div class="chat-send">
                                    <button class="btn btn-primary">Send</button>
                                </div>
                            </form>
                    </div>
                    <div class="chatbox-chats">
                    <?php

                    $sql = "SELECT * FROM chats";
                    $stmt = $dbh->prepare($sql);
                    $stmt->execute();
                    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    // print_r($result);
                    foreach ($result as $key => $value) {
                        
                    // check if session id is session sender
                    if ($value['user_send'] == $_SESSION['id']) {
                        ?>
                        
                        <div class="chatbox-container">
                            <img src="../assets/profile-picture.png" alt="Avatar" style="width:100%;">
                            <p style="text-align: left"><?php  echo $value['message']?></p>
                            <span class="time-right"><?php  echo $_SESSION['username'].' - '.  $value['date']?></span>
                        </div>
                        <?php
                        }
                        if ($value['user_recieved'] == $_SESSION['id']) {
                            ?>
                            <div class="chatbox-container darker">
                            <img src="../assets/driezie.png" alt="Avatar" class="right" style="width:100%;">
                            <p style="text-align: right"><?php  echo $value['message']?></p>
                            <span class="time-left"><?php  

                            // get username from id
                            $sql = "SELECT * FROM users WHERE id = ?";
                            $stmt = $dbh->prepare($sql);
                            $stmt->execute([$value['user_send']]);
                            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            echo $result[0]['username'].' - '.  $value['date']?></span>
                        </div>
                        <?php
                        }
                    
                    }
                        ?>


                    <!-- <div class="chatbox-chats">
                        <div class="chatbox-container">
                            <img src="../assets/profile-picture.png" alt="Avatar" style="width:100%;">
                            <p style="text-align: left">Hello. How are you today?</p>
                            <span class="time-right">officialjustdevv@gmail.com - 11:00</span>
                        </div>

                        <div class="chatbox-container darker">
                            <img src="../assets/driezie.png" alt="Avatar" class="right" style="width:100%;">
                            <p style="text-align: right">Hey! I'm fine. Thanks for asking! I am hewre for a message. This is a very long message because this is a big message</p>
                            <span class="time-left">11:01 - officialjustdevv@gmail.com</span>
                        </div> -->


                    </div>
                    
                    <!-- <p class="left">Is This order styll availible?</p>
                    <p class="right">Yes ofcourse it is!</p> -->
                    
                    </div>
                </div>
            </div>
        </section> 
    </main>

</body>
<script src="../js/app2.js"></script>
</html>
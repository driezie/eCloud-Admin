<?php

// Name: index.php
// Author: Jelte Cost
// Path: projects\simple-portfolio\index.php

require_once '../functions/dbh.php';
$dbh = dbConnection();

// adds visit counter to database by one 
function clientIpAddress(){
    if(!empty($_SERVER['HTTP_CLIENT_IP'])){
      $address = $_SERVER['HTTP_CLIENT_IP'];
    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
      $address = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }else{
      $address = $_SERVER['REMOTE_ADDR'];
    }
    return $address;
  }

function addVisitCounter() {
    global $dbh;
    $sql = "UPDATE config SET page_visits_login = page_visits_login + 1";
    $stmt = $dbh->prepare($sql);
    $stmt->execute();

    $sql = "INSERT INTO visits_log (id, ip, location, date, path) VALUES (NULL, :ip, :location, :date , :path)";
    $stmt = $dbh->prepare($sql);
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt->bindParam(':ip', $ip);
    $adress = clientIpAddress();
    $stmt->bindParam(':location', $adress);
    // set date to current date with seconds and minutes
    $date = date("Y-m-d H:i:s");
    $stmt->bindParam(':date', $date);

    // get path of the page from projects
    $path = $_SERVER['REQUEST_URI'];
    
    $stmt->bindParam(':path', $path);
    $stmt->execute();
} 
addVisitCounter();


// print array with all the data from the database
function printData() {
    global $dbh;
    $sql = "SELECT * FROM visits_log";
    $stmt = $dbh->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $result;
}
// echo "<pre>";
// print_r(printData());
// echo "</pre>";


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driezie's Portfolio</title>
    <!-- Scroll Reveal Libary -->
    <script src="https://unpkg.com/scrollreveal"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    
    <link rel="stylesheet" href="./../css/style.css">

    <!-- <link rel="stylesheet" href="./../css/chart.css"> -->
</head>
<body class="">
<header>
        <nav class="container">
            <a href="../" class="logo"> <b>Port<span>folio</span></b></a>
            <div class="links">
                <ul>
                    <li style="display: none;">
                        <span class="nav-link-menu" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
                    </li>
                    <li>
                        <a class="nav-link" href="../#1">Home</a>
                    </li>
                    <li>
                        <a class="nav-link" href="../#2">About me</a>
                    </li>
                        <a class='nav-link' href='../customer/'>Customer Login</a>
                    </li>
                </ul>
                <i class="uil uil-moon toggle-btn"></i>
            </div>
        </nav>
    </header>
    <main>
        <section class="showcase-area" id="1">
            <div class="container">
                <div class="showcase-info" style="min-height: 1000px;">
                <div class="welcome-top-buttons">
                    <!-- <a href="./profile.php" class="btn btn-primary">Mijn Profiel</a> -->
                    <a href="../" class="btn btn-primary">Terug</a>
                    <a href="mailto:j.cost@cadicto.nl" class="btn btn-primary">Contact Mij</a>
                </div>
                    <h3 class="sub-heading">Customer Login</h3>
                    <!-- create form -->
                    <form action="../functions/actions.php?value=login" method="POST">
                        <?php

                        if (isset($_GET['error'])) {
                            if ($_GET['error'] == "1") {
                                echo '<p class="error"><b>Please fill in everything!!</b></p>';
                            } else if ($_GET['error'] == "2") {
                                echo '<p class="error"><b>Wrong username or password!</b></p>';
                            } else if ($_GET['error'] == "3") {
                                echo '<p class="error"><b>You have been logged out succesfull!</b></p>';
                            }
                        }
                        ?>
                        <div class="g-input">
                            <input type="text" id="username" name="username" placeholder="Gebruikersnaam">
                        </div>

                        <div class="g-input">
                            <input type="password" id="password" name="password" placeholder="Wachtwoord">
                        </div>
                        <button type="submit" class="btn">Login</button><br><br>

                        <!-- <a href="https://discord.com/api/oauth2/authorize?response_type=code&client_id=157730590492196864&scope=webhook.incoming&state=15773059ghq9183habn&redirect_uri=" class="btn">Or Login using discord</a><br><br> -->

                        <p>
                            <br>
                            Forgot password? Please send an email to officialjustdevv@gmail.com to get a new password.
                        </p>
                    
                </div>
            </div>
        </section>
    </main>
</body>
<script src="../js/app2.js"></script>
</html>
<?php

// Name: dbh.php
// Author: Jelte Cost
// Path: TestingItems\login-simple\functions\dbh.php\


function dbConnection() {
    $host = "localhost";
    $dbname = "portfolio-driezie";
    $username = "root";
    $password = "";
    $dbConn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $dbConn;
}


// 2Yqm3#qY?ZkE@BC6
// 
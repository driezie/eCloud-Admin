<?php

// Name: actions.php
// Author: Jelte Cost
// Path: TestingItems\login-simple\functions\actions.php


require_once './dbh.php';
$dbh = dbConnection();

if ($_GET['value'] == 'login') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM users WHERE username = :username AND password = :password";
    $stmt = $dbh->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // check if the username and password is typed
    if (empty($username) || empty($password)) {
        header("Location: ../customer/login.php?error=1");
    } else {
        // check if the username and password is correct
        if (count($result) == 1) {
            session_start();
            $id = $result[0]['id'];
            $_SESSION['id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;
            if ($result[0]['role'] == 'admin') {
                $_SESSION['role'] = "admin";
            } else {
                $_SESSION['role'] = "customer";
            }
            // redirect to index.php
            header("Location: ../customer/index.php?alert=loggedin");
            // update last online
            // get ip
            $ip = $_SERVER['REMOTE_ADDR'];
            $sql = "UPDATE users SET last_online = NOW(), ip = :ip WHERE username = :username";
            $stmt = $dbh->prepare($sql);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':ip', $ip);
            $stmt->execute();

            // set ip to the user database

        } else {
            header("Location: ../customer/login.php?error=2");
        }
    }
}

if ($_GET['value'] == 'logout') {
    session_start();
    session_destroy();
    header("Location: ../customer/login.php?error=3");
}


if ($_GET['value'] == 'delete_order') {
    
    $id = $_GET['id'];
    $sql = "DELETE FROM orders WHERE id = :id";
    $stmt = $dbh->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    // check if succes
    if ($stmt->rowCount() == 1) {
        header("Location: ../admin/orders.php?alert=succes");
    } else {
        header("Location: ../admin/orders.php?alert=error");
    }
}

if ($_GET['value'] == 'update_order') {


    $id = $_GET['id'];
    // get posts

    
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_description = $_POST['product_description'];
    $product_date = $_POST['product_date'];
    $product_status = $_POST['product_status'];

    // print all
    echo $product_name . "<br>";
    echo $product_price . "<br>";
    echo $product_description . "<br>";
    echo $product_date . "<br>";
    echo $product_status . "<br>";
    

    // update product
    $sql = "UPDATE orders SET product_name = :product_name, product_price = :product_price, product_description = :product_description, product_date = :product_date, product_status = :product_status WHERE id = :id";
    $stmt = $dbh->prepare($sql);

    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':product_name', $product_name);
    $stmt->bindParam(':product_price', $product_price);
    $stmt->bindParam(':product_description', $product_description);
    $stmt->bindParam(':product_date', $product_date);
    $stmt->bindParam(':product_status', $product_status);
    
    $stmt->execute();


    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // check if succes
    if ($stmt->rowCount() == 1) {
        header("Location: ../admin/edit_order.php?id=" . $id . "&alert=2");
    } else {
        header("Location: ../admin/edit_order.php?id=" . $id . "&alert=3");
    }
}



if ($_GET['value'] == 'create_order') {
    // get posts
    $customer_id = $_POST['customer_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_description = $_POST['product_description'];
    $product_date = $_POST['product_date'];
    $product_status = $_POST['product_status'];

    // print all
    echo $product_name . "<br>";
    echo $product_price . "<br>";
    echo $product_description . "<br>";
    echo $product_date . "<br>";
    echo $product_status . "<br>";

    // insert product
    $sql = "INSERT INTO orders (customer_id,product_name, product_price, product_description, product_date, product_status) VALUES (:customer_id, :product_name, :product_price, :product_description, :product_date, :product_status)";
    $stmt = $dbh->prepare($sql);

    $stmt->bindParam(':customer_id', $customer_id);
    $stmt->bindParam(':product_name', $product_name);
    $stmt->bindParam(':product_price', $product_price);
    $stmt->bindParam(':product_description', $product_description);
    $stmt->bindParam(':product_date', $product_date);
    $stmt->bindParam(':product_status', $product_status);

    $stmt->execute();

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // check if succes
    if ($stmt->rowCount() == 1) {
        header("Location: ../admin/orders.php?alert=Succesful added to Database!");
    } else {
        header("Location: ../admin/orders.php?alert=Something went wrong!");
    }
}


if ($_GET['value'] == 'create_user') {
    
    // get posts
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // print all
    echo $username . "<br>";
    echo $password . "<br>";
    echo $role . "<br>";

    // insert product
    $sql = "INSERT INTO users (username, password, role) VALUES (:username, :password, :role)";
    $stmt = $dbh->prepare($sql);

    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':role', $role);

    $stmt->execute();

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // check if succes
    if ($stmt->rowCount() == 1) {
        header("Location: ../admin/users.php?alert=Succesful added to Database!");
    } else {
        header("Location: ../admin/users.php?alert=Something went wrong!");
    }


}

if ($_GET['value'] == 'delete_user') {
        
    $id = $_GET['id'];
    $sql = "DELETE FROM users WHERE id = :id";
    $stmt = $dbh->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    // check if succes
    if ($stmt->rowCount() == 1) {
        // delete orders from user
        $sql = "DELETE FROM orders WHERE customer_id = :id";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        header("Location: ../admin/users.php?alert=Succesful deleted from Database! +orders deleted");

    } else {
        header("Location: ../admin/users.php?alert=error");
    }
}


if ($_GET['value'] == 'update_user') {
    $id = $_GET['id'];
    // get posts
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // print all
    echo $username . "<br>";
    echo $password . "<br>";
    // remove customer from the text $role
    $role = str_replace(" selected", "", $role);
    echo $role . "<br>";

    // update user
    $sql = "UPDATE users SET username = :username, password = :password, role = :role WHERE id = :id";
    $stmt = $dbh->prepare($sql);

    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':role', $role);

    $stmt->execute();

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // check if succes
    if ($stmt->rowCount() == 1) {
        header("Location: ../admin/users.php?alert=Succesful updated in Database!");
    } else {
        header("Location: ../admin/users.php?alert=Something went wrong!");
    }
}
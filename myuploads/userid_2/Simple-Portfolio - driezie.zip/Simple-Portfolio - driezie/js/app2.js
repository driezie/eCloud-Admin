// Name: app.js
// Author: Jelte Cost
// Path: projects\simple-portfolio\js\app.js

const header = document.querySelector('header');

/* -- Sticky Navbar -- */
function stickyNavbar() {
    header.classList.toggle('scrolled', window.scrollY > 0);
    // console.log(window.scrollY);
}

stickyNavbar();

window.addEventListener('scroll', stickyNavbar);

/* -- Reveal Homepage-- */

let sr = ScrollReveal({
    duration: 2500,
    distance: '60px',
});

sr.reveal(".showcase-info", { delay: 100 });
sr.reveal(".showcase-image", { origin: "top", delay: 300 });

sr.reveal(".welcome-info", { delay: 200 });

sr.reveal(".modal-content", { origin: "top", delay: 40 });

//button click on toggle-btn will give class dark to body and remove class dark from body
const toggleBtn = document.querySelector('.toggle-btn');
const body = document.querySelector('body');
// button press will give class dark to body and remove class dark from body

// check if website reloaded
console.log(localStorage.getItem('theme'));


// if localstorage is not empty
if (localStorage.getItem('theme') == 'dark') {
    body.classList.toggle('dark');
    // else
} else {
    body.classList.remove('dark');
}




toggleBtn.addEventListener('click', () => {
    if (localStorage.getItem('theme') == 'dark') {
        body.classList.remove('dark');
        localStorage.setItem('theme', 'light');
        // else
    } else {
        body.classList.toggle('dark');
        localStorage.setItem('theme', 'dark');
    }

    // else if dark, set theme to dark

});

var modal = document.getElementById("myModal");
localStorage.setItem('welcomealert1', 'false');
// Get the button that opens the modal
var btn = document.getElementById("myBtn");

if (localStorage.getItem('welcomealert1') == 'false') {
    modal.style.display = "none";
} else {
    modal.style.display = "block";

}



window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
        localStorage.setItem('welcomealert1', 'false');
    }
}
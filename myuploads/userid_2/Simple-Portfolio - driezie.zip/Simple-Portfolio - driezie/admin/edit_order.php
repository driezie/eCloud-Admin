<?php

// Name: index.php
// Author: Jelte Cost
// Path: projects\simple-portfolio\index.php

require_once '../functions/dbh.php';
$dbh = dbConnection();

session_start();

if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
    // print_r($_SESSION);

} else {
    header("Location: ./login.php");
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driezie's Portfolio</title>
    <!-- Scroll Reveal Libary -->
    <script src="https://unpkg.com/scrollreveal"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    
    <link rel="stylesheet" href="../css/style.css">

    <link rel="stylesheet" href="../css/chart.css">
</head>
<body class="">
    <header>
        <nav class="container">
            <a href="./" class="logo"> <b>Dash<span>board</span></b></a>
            <div class="links">
                <ul>
                    <li style="display: none;">
                        <span class="nav-link-menu" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
                    </li>
                    <li>
                        <a class="nav-link" href="./">Home</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./orders.php">All orders</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./users.php">All Users</a>
                    </li>
                    <li>
                        <a class="nav-link" href="../functions/actions.php?value=logout"><b>Logout</b> (<?= $_SESSION[ 'username'] ?>)</a>
                    </li>
                    <li>
                    </li>
                </ul>
                <i class="uil uil-moon toggle-btn"></i>
            </div>
        </nav>
    </header>
    
    <main>
    <section class="showcase-area" id="1">
            <div class="container">
                <div class="showcase-info" style="min-height: 1000px;">
                <div class="welcome-top-buttons">
                    <!-- <a href="./profile.php" class="btn btn-primary">Mijn Profiel</a> -->
                    <a class="btn btn-primary" href="./orders.php">Terug</a>
                    <a href="../functions/actions.php?value=logout" class="btn btn-primary">Logout</a>
                </div>
                <?php

                // get data from database from id of orders
                $sql = "SELECT * FROM orders WHERE id = ?";
                $stmt = $dbh->prepare($sql);
                $stmt->execute([$_GET['id']]);
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);


                // get username from database from customer_id of orders
                $sql = "SELECT username FROM users WHERE id = ?";
                $stmt = $dbh->prepare($sql);
                $stmt->execute([$result[0]['customer_id']]);
                $result2 = $stmt->fetchAll(PDO::FETCH_ASSOC);


                

                // get order name from $result
                // $order_name = $result[0]['orde/r_name'];
                ?>






                    <h3 class="sub-heading">Editing, <?= $order_name = $result[0]['product_name'] . ' - (' . $result2['0']['username']. ')'; ?></h3>
                    <!-- create form -->
                    <form action="../functions/actions.php?value=update_order&id=<?= $_GET['id'] ?>" method="POST">
                        <?php

                        if (isset($_GET['alert'])) {
                            if ($_GET['alert'] == "1") {
                                echo '<p class="error"><b>Please fill in everything!!</b></p>';
                            } else if ($_GET['alert'] == "2") {
                                echo '<p class="error"><b>Succesful updated!</b></p>';
                            } 
                            else if ($_GET['alert'] == "3") {
                                echo '<p class="error"><b>Something went wrong when uploading to database!</b></p>';
                            } 

                        }

                        


                        ?>
                        <div class="g-input">
                        <label for="">Product Name: </label>
                            <input type="text" id="username" name="product_name" placeholder="Name"  value="<?= $result[0]['product_name']; ?>">
                        </div>

                        <div class="g-input">
                        <label for="">Product Price: </label>
                            <input type="text" id="username" name="product_price" placeholder="Price" value="<?= $result[0]['product_price']; ?>">
                        </div>

                        <div class="g-input">
                            <label for="">Description: </label>
                            <input type="text" id="username" name="product_description" placeholder="Description" value="<?= $result[0]['product_description']; ?>" rows="3">
                        </div>

                        <div class="g-input">
                        <label for="">Date Started: </label>
                            <input type="text" id="username" name="product_date" placeholder="Gebruikersnaam" value="<?= $result[0]['product_date']; ?>">
                        </div>

                        
                        <div class="g-input">
                            <select name="product_status" id="product_status">
                                <?php
                                // if order is in progress
                                if ($result[0]['product_status'] == "1") {
                                    echo '<option value="1" selected>In progress</option>';
                                    echo '<option value="2">Done</option>';
                                    echo '<option value="3">Canceled</option>';
                                    echo '<option value="4">Delayed</option>';
                                } else if ($result[0]['product_status'] == "2") {
                                    echo '<option value="1">In progress</option>';
                                    echo '<option value="2" selected>Done</option>';
                                    echo '<option value="3">Canceled</option>';
                                    echo '<option value="4">Delayed</option>';

                                } else if ($result[0]['product_status'] == "3") {
                                    echo '<option value="1">In progress</option>';
                                    echo '<option value="2">Done</option>';
                                    echo '<option value="3" selected>Canceled</option>';
                                    echo '<option value="4">Delayed</option>';

                                } else if ($result[0]['product_status'] == "4") {
                                    echo '<option value="1">In progress</option>';
                                    echo '<option value="2">Done</option>';
                                    echo '<option value="3">Canceled</option>'; 
                                    echo '<option value="4" selected>Delayed</option>';
 
                                }

                                ?>

                            </select> 

                            
                        </div><br>

                        <button type="submit" class="btn">Update</button>    
                        <a href='../functions/actions.php?value=delete_order&id=<?= $_GET['id']; ?>' class='btn'>Verwijderen</a></p>            
                </div>
            </div>
        </section>
    </main>

    <!-- Javascript scripts -->

    <script src="../js/app2.js"></script>

</body>
</html>
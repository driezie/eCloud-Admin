<?php

// Name: index.php
// Author: Jelte Cost
// Path: projects\simple-portfolio\index.php

require_once '../functions/dbh.php';
$dbh = dbConnection();

session_start();

if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
    // print_r($_SESSION);

} else {
    header("Location: ./login.php");
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driezie's Portfolio</title>
    <!-- Scroll Reveal Libary -->
    <script src="https://unpkg.com/scrollreveal"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    
    <link rel="stylesheet" href="../css/style.css">

    <link rel="stylesheet" href="../css/chart.css">
</head>
<body class="">
    <header>
        <nav class="container">
            <a href="./" class="logo"> <b>Dash<span>board</span></b></a>
            <div class="links">
                <ul>
                    <li style="display: none;">
                        <span class="nav-link-menu" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
                    </li>
                    <li>
                        <a class="nav-link" href="./">Home</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./orders.php">All orders</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./users.php">All Users</a>
                    </li>
                    <li>
                        <a class="nav-link" href="../functions/actions.php?value=logout"><b>Logout</b> (<?= $_SESSION[ 'username'] ?>)</a>
                    </li>
                    <li>
                    </li>
                </ul>
                <i class="uil uil-moon toggle-btn"></i>
            </div>
        </nav>
    </header>
    
    <main>
    <section class="showcase-area" id="1">
            <div class="container">
                <div class="showcase-info" style="min-height: 1000px;">
                <div class="welcome-top-buttons">
                    <!-- <a href="./profile.php" class="btn btn-primary">Mijn Profiel</a> -->
                    <a class="btn btn-primary" href="./orders.php">Terug</a>
                    <a href="../functions/actions.php?value=logout" class="btn btn-primary">Logout</a>
                </div>
                    <h3 class="sub-heading">Creating user</h3>
                    <!-- create form -->
                    <form action="../functions/actions.php?value=create_user" method="POST">
                        <div class="g-input">
                        <label for="">Username: </label>
                            <input type="text" id="username" name="username" placeholder="Name">
                        </div>

                        <div class="g-input">
                        
                        <label for="">Password: </label> <div id="button" class="btn"onclick="genPassword()">Generate password</div>
                            <input type="text" id="password" name="password" placeholder="Password" >
                        </div>

                        
                        <div class="g-input">
                            <select name="role" id="role">
                                <?php
                                // if order is in progress
                                echo '<option value="customer" selected>Customer</option>';
                                echo '<option value="admin">Admin</option>';
                                ?>

                            </select> 

                            
                        </div><br>

                        <button type="submit" class="btn">Create User</button><br><br>                    
                </div>
            </div>
        </section>
    </main>

    <!-- Javascript scripts -->
<script src="../js/pass.js"></script>
    <script src="../js/app2.js"></script>

</body>
</html>
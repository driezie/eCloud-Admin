<?php

// Name: index.php
// Author: Jelte Cost
// Path: projects\simple-portfolio\index.php

require_once '../functions/dbh.php';
$dbh = dbConnection();

session_start();

if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
    // print_r($_SESSION);

} else {
    header("Location: ./login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driezie's Portfolio</title>
    <!-- Scroll Reveal Libary -->
    <script src="https://unpkg.com/scrollreveal"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    
    <link rel="stylesheet" href="../css/style.css">

    <!-- testingItems -->   
    <link rel="stylesheet" href="../css/chart.css">
</head>
<body class="">
    <header>
        <nav class="container">
            <a href="./" class="logo"> <b>Dash<span>board</span></b></a>
            <div class="links">
                <ul>
                    <li style="display: none;">
                        <span class="nav-link-menu" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
                    </li>
                    <li>
                        <a class="nav-link" href="./">Home</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./orders.php">All orders</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./users.php">All Users</a>
                    </li>
                    <li>
                        <a class="nav-link" href="../functions/actions.php?value=logout"><b>Logout</b> (<?= $_SESSION[ 'username'] ?>)</a>
                    </li>
                    <li>
                    </li>
                </ul>
                <i class="uil uil-moon toggle-btn"></i>
            </div>
        </nav>
    </header>
    
    <main>
        <section class="welcome-area" id="1">
            <div class="container" >
                
                <div class="welcome-info" style="min-height: 1000px;">
                <div class="welcome-top-buttons">
                <a class="btn btn-primary" href="./orders.php">All Orders</a>
                    <a class="btn btn-primary" href="./users.php">All Users</a>
                    <a href="../functions/actions.php?value=logout" class="btn btn-primary">Logout</a>
                </div>

                    <h3 class="sub-heading">Welcome, <?= $_SESSION[ 'username'] ?>! </h3>
                    <h1 class="heading">All Users</h1>
                    <?php
                        $id = $_SESSION['id'];
                        $sql = "SELECT * FROM users WHERE role = 'customer' except (SELECT * FROM users WHERE  id = $id and username = 'admin')";
                        $stmt = $dbh->prepare($sql);
                        $stmt->execute();
                        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        $count = count($result);
                        ?>
                        <br>
                        <p class="counter-number">Total Users: <?= $count ?>  <a href='./create_user.php'> (Nieuw)</a></p></p><br>
                    
                        <div class="alert">
                            <?php

                            if (isset($_GET['alert'])) {
                                echo '<p class="error"><b>'.$_GET['alert'].'</b></p>';  
                            }
                            ?>
                        </div>
                    <div class="list">
                        
                        <?php
                        // for each order name from result
                            foreach ($result as $log) {
                                

                                echo '<div class="item">';
                                echo '<p>UserId - <b>'.$log['id'].'</b></p>';
                                echo '<p>IP: - <b>'.$log['ip'].'</b></p>';
                                echo '<p>Username - <b>'.$log['username'].'</b></p>';
                                echo '<p>Role - <b>'.$log['role'].'</b></p>';
                                echo '<p>Last logged in at - <b>'.$log['last_online'].'</b></p>';

                                echo '<input id="myInput" class="password_input" type="text" value='.$log["password"].'>';
                                // echo '<button > Show Password</button>';

                                echo "<a href='./edit_user.php?id=".$log['id']."' class='btn'>Bewerken</a> ";
                                echo "<a href='../functions/actions.php?value=delete_user&id=".$log['id']."' class='btn'>Verwijder gebruiker</a></p>";
                                echo "</div>";
                            }

                        
                       




                        ?>
                    </div>
                </div>
            </div>
        </section> 
    </main>

    <!-- Javascript scripts -->

    <script src="../js/app2.js"></script>

    <script>
        function myFunction() {
        var x = document.getElementById("myInput");
        // change the type of the input to text and rename the button to hide
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }


        }
    </script>

</body>
</html>
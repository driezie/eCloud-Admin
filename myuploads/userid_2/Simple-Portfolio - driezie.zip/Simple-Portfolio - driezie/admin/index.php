<?php

// Name: index.php
// Author: Jelte Cost
// Path: projects\simple-portfolio\index.php

require_once '../functions/dbh.php';
$dbh = dbConnection();

session_start();

if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
    if ($_SESSION['role'] == 'customer') {
        header("Location: ../customer/index.php");
    } 

} else {
    header("Location: ./login.php");
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driezie's Portfolio</title>
    <!-- Scroll Reveal Libary -->
    <script src="https://unpkg.com/scrollreveal"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    
    <link rel="stylesheet" href="../css/style.css">
    <!-- <link rel="stylesheet" href="../css/chatbox.css"> -->
    <!-- <link rel="stylesheet" href="../css/app2.js"> -->
    <!-- <link rel="stylesheet" href="../css/chart.css"> -->


</head>
<body class="">
    <header>
        <nav class="container">
            <a href="./index.php" class="logo"> <b>Dash<span>board</span></b></a>
            <div class="links">
                <ul>
                    <li style="display: none;">
                        <span class="nav-link-menu" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
                    </li>
                    <li>
                        <a class="nav-link" href="./index.php">Home</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./orders.php">All Orders</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./users.php">All Users</a>
                    </li>
                    <li>
                        <a class="nav-link" href="../functions/actions.php?value=logout"><b>Logout</b> (<?= $_SESSION[ 'username'] ?>)</a>
                    </li>
                    <li>
                    </li>
                </ul>
                <i class="uil uil-moon toggle-btn"></i>
            </div>
        </nav>
    </header>
    
    <main>
        <section class="welcome-area" id="1">
            <div class="container" >
                
                <div class="welcome-info" style="min-height: 1000px;">
                <div class="welcome-top-buttons">
                    <a class="btn btn-primary" href="./orders.php">All Orders</a>
                    <a class="btn btn-primary" href="./users.php">All Users</a>
                    <a href="../functions/actions.php?value=logout" class="btn btn-primary">Logout</a>
                </div>

                    <h3 class="sub-heading">Welcome, <?= $_SESSION[ 'username'] ?>! </h3>
                    <h1 class="heading">Dashboard</h1>
                    <div class="counter">
                        <p class="text">All Time Visits: <b>
                            <?php
                            //print count($orders);
                            $id = $_SESSION['id'];
                            $sql = "SELECT * FROM config";
                            $stmt = $dbh->prepare($sql);
                            $stmt->execute();
                            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            echo $result[0]['page_visits_index'] + $result[0]['page_visits_login'];
                            ?>
                        </b></p>

                        <p class="text">Homepage Visits: <b>
                            <?= $result[0]['page_visits_index']; ?>
                        </b></p>
                        <p class="text">Login Visits: <b>
                        <?= $result[0]['page_visits_login']; ?>
                        </b></p>
                        <!-- <p class="text">Orders: <b>0</b></p> -->
                    </div>
                    <div class="counter">
                        <p class="text">All Orders: <b>
                            <?php
                            //print count($orders);
                            $id = $_SESSION['id'];
                            $sql = "SELECT * FROM orders";
                            $stmt = $dbh->prepare($sql);
                            $stmt->execute();
                            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            echo count($result);
                            ?>

                            
                        </b></p>

                        <p class="text">All Completed Orders: <b>
                            <?php
                            //print count($orders);
                            $sql2 = "SELECT * FROM orders WHERE product_status = '2'";
                            $stmt2 = $dbh->prepare($sql2);
                            $stmt2->execute();
                            $result2 = $stmt2->fetchAll(PDO::FETCH_ASSOC);
                            echo count($result2);
                            ?>
                        </b></p>
                        <p class="text">All Canceled Orders: <b>
                            <?php
                            //print count($orders);
                            $sql2 = "SELECT * FROM orders WHERE product_status = '3'";
                            $stmt2 = $dbh->prepare($sql2);
                            $stmt2->execute();
                            $result2 = $stmt2->fetchAll(PDO::FETCH_ASSOC);
                            echo count($result2);
                            ?>
                        </b></p>
                        <!-- <p class="text">Orders: <b>0</b></p> -->
                    </div>
                    
                    <div class="cta">
                    <p>Create an order <a href="./create_order.php">here</a></p> 
                    </div>
                </div>
            </div>
        </section> 
    </main>
</body>
<script src="../js/app2.js"></script>
</html>
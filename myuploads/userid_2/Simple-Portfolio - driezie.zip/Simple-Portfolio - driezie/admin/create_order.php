<?php

// Name: index.php
// Author: Jelte Cost
// Path: projects\simple-portfolio\index.php

require_once '../functions/dbh.php';
$dbh = dbConnection();

session_start();

if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
    // print_r($_SESSION);

} else {
    header("Location: ./login.php");
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driezie's Portfolio</title>
    <!-- Scroll Reveal Libary -->
    <script src="https://unpkg.com/scrollreveal"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    
    <link rel="stylesheet" href="../css/style.css">

    <link rel="stylesheet" href="../css/chart.css">
</head>
<body class="">
    <header>
        <nav class="container">
            <a href="./" class="logo"> <b>Dash<span>board</span></b></a>
            <div class="links">
                <ul>
                    <li style="display: none;">
                        <span class="nav-link-menu" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
                    </li>
                    <li>
                        <a class="nav-link" href="./">Home</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./orders.php">All orders</a>
                    </li>
                    <li>
                        <a class="nav-link" href="./users.php">All Users</a>
                    </li>
                    <li>
                        <a class="nav-link" href="../functions/actions.php?value=logout"><b>Logout</b> (<?= $_SESSION[ 'username'] ?>)</a>
                    </li>
                    <li>
                    </li>
                </ul>
                <i class="uil uil-moon toggle-btn"></i>
            </div>
        </nav>
    </header>
    
    <main>
    <section class="showcase-area" id="1">
            <div class="container">
                <div class="showcase-info" style="min-height: 1000px;">
                <div class="welcome-top-buttons">
                    <!-- <a href="./profile.php" class="btn btn-primary">Mijn Profiel</a> -->
                    <a class="btn btn-primary" href="./orders.php">Terug</a>
                    <a href="../functions/actions.php?value=logout" class="btn btn-primary">Logout</a>
                </div>
                    <h3 class="sub-heading">Creating order</h3>
                    <!-- create form -->
                    <form action="../functions/actions.php?value=create_order" method="POST">

                        <div class="g-input">
                            <select name="customer_id" id="customer_id">
                                <?php
                                // create an option for every user  from database
                                $sql = "SELECT * FROM users Except SELECT * FROM users WHERE id = '" . $_SESSION['id'] . "'";
                                $stmt = $dbh->prepare($sql);
                                $stmt->execute();
                                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($result as $row) {
                                    echo '<option value="' . $row['id'] . '">' .$row['id'] .' - '. $row['username'] . '</option>';
                                }
                                // echo '<option value="1" selected>In progress</option>';
                                // echo '<option value="2">Done</option>';
                                // echo '<option value="3">Canceled</option>';
                                // echo '<option value="4">Delayed</option>';

                                ?>

                            </select> 
                            
                        </div><br>

                        <div class="g-input">
                        <label for="">Product Name: </label>
                            <input type="text" id="username" name="product_name" placeholder="Name">
                        </div>

                        <div class="g-input">
                        <label for="">Product Price: </label>
                            <input type="text" id="username" name="product_price" placeholder="Price" >
                        </div>

                        <div class="g-input">
                            <label for="">Description: </label>
                            <input type="text" id="username" name="product_description" placeholder="Description" rows="3">
                        </div>

                        <div class="g-input">
                        <label for="">Date Started: </label>
                            <input type="text" id="username" name="product_date" placeholder="Gebruikersnaam" >
                        </div>

                        
                        <div class="g-input">
                            <select name="product_status" id="product_status">
                                <?php
                                // if order is in progress
                                echo '<option value="1" selected>In progress</option>';
                                echo '<option value="2">Done</option>';
                                echo '<option value="3">Canceled</option>';
                                echo '<option value="4">Delayed</option>';

                                ?>

                            </select> 

                            
                        </div><br>

                        <button type="submit" class="btn">Update</button><br><br>                    
                </div>
            </div>
        </section>
    </main>

    <!-- Javascript scripts -->

    <script src="../js/app2.js"></script>

</body>
</html>